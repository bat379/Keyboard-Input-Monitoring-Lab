# Keyboard Input Monitoring Lab

A beginner-friendly, **educational** Python project that demonstrates the
technical mechanics of keyboard-input monitoring — safely, transparently,
and entirely inside its own application window.

> **This is a training simulator, not a keylogger.** It cannot capture
> keystrokes from other applications or browsers, does not run in the
> background, installs no OS-level hook, and never stores real passwords
> or authentication data. See [Security Limitations & Boundaries](#security-limitations--boundaries)
> below for the full list of what this project deliberately does *not* do.

Built for use in an isolated security-training environment, such as an
OWASP-style lab VM or classroom sandbox.

---

## Table of Contents

- [Educational Objectives](#educational-objectives)
- [Features](#features)
- [Architecture](#architecture)
- [Installation](#installation)
  - [PEP 668 / "externally-managed-environment" troubleshooting](#pep-668--externally-managed-environment-troubleshooting)
- [Usage](#usage)
- [Running the Tests](#running-the-tests)
- [Security Limitations & Boundaries](#security-limitations--boundaries)
- [Project Structure](#project-structure)

---

## Educational Objectives

After working through this lab, a student should be able to explain:

1. **How input focus scopes event delivery.** GUI toolkits (like Tkinter)
   only deliver keyboard events to whichever widget currently holds
   input focus *within that application*. This lab's `Monitor` tab
   binds its key handler to a single text box — nothing more — which
   is why it can never "see" what you type into another program.
2. **The difference between focus-scoped capture and OS-level hooking.**
   Real-world keyloggers use system hooks (Windows `SetWindowsHookEx`,
   Linux/X11 keyboard grabs, macOS `CGEventTap`, etc.) or global-listener
   libraries to intercept input *system-wide*, regardless of which
   window is focused. This project intentionally contains **none** of
   that — it's a useful contrast to point at when discussing why real
   keyloggers are dangerous.
3. **Redact-at-the-source design.** The mock login form's password
   value is converted to a fixed placeholder (`[REDACTED]`) the instant
   it's read from the widget — before it reaches any log, event
   callback, or database write. Nothing downstream of that line ever
   sees the raw characters, or even the password's length.
4. **Local-only, minimal, and transparent data handling.** All
   collected data is synthetic, stored in a local SQLite file, and
   fully visible/erasable by the user via the Dashboard and "Clear Test
   Data" button — the opposite of how spyware hides its exfiltration
   and storage from its victim.
5. **Why "monitoring my own test window" and "monitoring a user's
   real activity" are fundamentally different problems** — legally,
   ethically, and technically.

---

## Features

- **CustomTkinter desktop GUI** with three tabs: `Monitor`, `Safe Test
  Mode`, and `Dashboard`.
- **Start Monitoring / Stop Monitoring** buttons with a live status
  indicator. Monitoring is **off by default** on every launch.
- **Focus-scoped keystroke capture** — only active while the app's own
  test textbox has input focus, and only while monitoring is running.
- **Safe Test Mode**: a mock login form (Username, Password, Submit)
  that is not wired to any real authentication system. On submit, it
  logs an educational event:
  ```
  Username field: [TEST INPUT]
  Password field: [REDACTED]
  ```
- **No real password characters are ever recorded or displayed**,
  anywhere in the codebase.
- **SQLite storage**, local file only, synthetic test data only.
- **Clear Test Data** button to wipe the local database instantly.
- **Educational Dashboard** showing:
  - Number of test keystrokes
  - Number of test sessions
  - Number of simulated login attempts
  - Number of passwords redacted
- **Unit tests** covering the redaction logic, the key-event handler,
  and the database layer.
- Extensive inline comments explaining the security concept behind
  each important section of code.

---

## Architecture

```
┌─────────────────────────────┐
│           main.py           │   Entry point — launches the GUI
└──────────────┬───────────────┘
               │
               ▼
┌─────────────────────────────┐
│          gui/app.py         │   Main window: tabs, Start/Stop buttons,
│                              │   wires widget events to monitor/ and
│                              │   database/ modules
└──────┬───────────────┬──────┘
       │               │
       ▼               ▼
┌─────────────┐  ┌───────────────────┐
│ gui/         │  │ gui/dashboard.py  │
│ login_form.py│  │ (stats display)   │
│ (mock login) │  └────────┬──────────┘
└──────┬───────┘           │
       │                   │
       ▼                   ▼
┌─────────────────────────────┐      ┌───────────────────────────┐
│  monitor/key_event_handler.py│─────▶│  database/db_manager.py   │
│  monitor/redactor.py         │      │  (SQLite, local file only)│
└─────────────────────────────┘      └───────────────────────────┘
```

**Key design decision:** capture is bound at the *widget* level
(`widget.bind("<KeyPress>", ...)`), not at the OS or window-manager
level. Tkinter/CustomTkinter only route key events to the widget that
currently owns input focus, and only within this process. There is no
code path anywhere in this project that registers a system-wide hook,
listens for events from another process, or targets any other
application window (including browsers).

---

## Installation

Requires **Python 3.9+**.

```bash
# 1. Clone or copy the project, then move into it
cd keyboard_input_monitoring_lab

# 2. Create an isolated virtual environment (strongly recommended,
#    and required on distros that enforce PEP 668 — see below)
python3 -m venv .venv

# 3. Activate it
source .venv/bin/activate        # macOS/Linux
.venv\Scripts\activate           # Windows (PowerShell/CMD)

# 4. Install dependencies
pip install -r requirements.txt

# 5. Run the app
python main.py
```

### PEP 668 / "externally-managed-environment" troubleshooting

On modern Debian/Ubuntu-based systems (and some other Linux distros),
running `pip install` directly against the system Python raises:

```
error: externally-managed-environment

× This environment is externally managed
╰─> To install Python packages system-wide, try apt install
    python3-xyz, or use a virtual environment.
```

This is expected behavior under **PEP 668** — it prevents `pip` from
modifying the OS's managed Python installation. **The fix is to always
install into a virtual environment**, which is exactly what the steps
above do. A few notes if you still hit issues:

- **"python3-venv not found" / `venv` module missing (Debian/Ubuntu):**
  ```bash
  sudo apt update && sudo apt install python3-venv python3-tk
  ```
  (`python3-tk` provides the underlying Tkinter bindings that
  CustomTkinter builds on — it's a separate OS package, not a pip
  package, on most Linux distros.)

- **Never use `--break-system-packages` for this project.** It's
  possible to bypass PEP 668 that way, but it defeats the purpose of
  keeping this lab's dependencies isolated from your system Python —
  use the virtual environment instead.

- **Confirming you're in the venv:** your shell prompt should show
  `(.venv)` at the start of the line, and `which python` (or `where
  python` on Windows) should point inside the `.venv` folder.

- **Deactivating when you're done:**
  ```bash
  deactivate
  ```

---

## Usage

1. Launch the app: `python main.py`
2. On the **Monitor** tab:
   - Click **Start Monitoring** (status indicator turns green /
     "RUNNING").
   - Click into the text box and type anything — this is synthetic
     test input. Each keystroke appears in the **Captured Test
     Keystroke Log** below, labeled (e.g. `Key: a`, `Key: Space`).
   - Click into another application's window and type — nothing is
     logged, because that window never had focus inside this app.
   - Click **Stop Monitoring** to halt capture immediately.
3. On the **Safe Test Mode** tab:
   - Enter any placeholder text into **Username** and **Password**
     (these are not real credentials and go nowhere outside this app).
   - Click **Submit (Simulated Login)**.
   - Observe the educational event logged:
     ```
     Username field: [TEST INPUT]
     Password field: [REDACTED]
     ```
4. On the **Dashboard** tab:
   - View aggregate counts of test keystrokes, sessions, simulated
     login attempts, and redacted passwords.
   - Click **Refresh Stats** to re-read the latest counts.
5. Click **Clear Test Data** (bottom-right, always visible) at any
   time to wipe the local SQLite database (`database/lab_data.sqlite3`).

---

## Running the Tests

```bash
# From the project root, with the virtual environment activated
python -m unittest discover -s tests -v
```

This runs:
- `tests/test_redactor.py` — proves the password/username redaction
  functions never leak raw values, length, or partial content.
- `tests/test_key_handler.py` — proves no key events are produced
  unless monitoring has been explicitly started, and that stopping
  halts processing immediately.
- `tests/test_db_manager.py` — proves database operations (session
  lifecycle, keystroke logging, login-attempt logging, stats, and
  clearing) behave correctly against a temporary SQLite file.

---

## Security Limitations & Boundaries

This project is intentionally limited in scope. It is **not** a
general-purpose monitoring tool, and it must not be extended into one.
Specifically, this codebase:

- **Never** installs a system-wide/OS-level keyboard hook, driver, or
  accessibility-API listener.
- **Never** captures input from any window other than its own —
  including when that window loses focus.
- **Never** targets, detects, fingerprints, or interacts with Chrome,
  Firefox, Edge, Safari, or any other browser.
- **Never** inspects HTTPS traffic, browser tabs, URLs, cookies,
  sessions, saved passwords, or authentication tokens.
- **Never** stores real passwords, password lengths, password hashes,
  or any derivative of password content — the mock login form's
  password field is redacted to a fixed placeholder before it reaches
  any logging or storage code.
- **Never** uses stealth, persistence, auto-start/startup-execution,
  process injection, DLL injection, browser extensions, credential
  dumping, or anti-detection/evasion techniques of any kind.
- **Never** transmits data over a network — all storage is a local
  SQLite file, and the codebase contains no networking code.
- Is **off by default**: monitoring must be explicitly started by the
  user for every session, every launch.
- Is **fully transparent**: everything captured is visible in the GUI
  in real time and can be inspected or erased by the user at any
  point.

If you are building on this project, preserve all of the above
constraints. This lab is meant to teach *how monitoring works
technically*, and *why unscoped, hidden, cross-application monitoring
is dangerous* — not to provide a starting point for building real
credential-stealing software.

---

## Project Structure

```
keyboard_input_monitoring_lab/
├── main.py                      # Entry point
├── requirements.txt
├── README.md
├── gui/
│   ├── app.py                   # Main window, tabs, Start/Stop wiring
│   ├── dashboard.py              # Educational Dashboard tab
│   └── login_form.py             # Safe Test Mode mock login form
├── monitor/
│   ├── key_event_handler.py      # Focus-scoped key event processing
│   └── redactor.py               # Password/username redaction logic
├── database/
│   ├── db_manager.py             # SQLite persistence (local file only)
│   └── lab_data.sqlite3          # Created automatically on first run
└── tests/
    ├── test_key_handler.py
    ├── test_redactor.py
    └── test_db_manager.py
```
